#!/bin/bash

# @author : Sébastien LOZANO

##########################################################################################
#  Script pour copier des fichier, notamment sous windows afin de forcer
# l'utilisation du powershell
#########################################################################################

cp $1 $2